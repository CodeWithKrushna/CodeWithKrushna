package com.anudip.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

//create table Employee(id int, empName varchar(30), empsal BigInt, empemail varchar(50),empDesign varchar(30),doj varchar);
@Entity
public class Employee 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(length = 30)
	private String empName;
	@Column(length = 20)
	private int empsal;
	@Column(length = 30)
	private String empemail;
	@Column(length = 20)
	private String empDesign;
	@Column(length = 20)
	private String doj;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int id, String empName, int empsal, String empemail, String empDesign, String doj) {
		super();
		this.id = id;
		this.empName = empName;
		this.empsal = empsal;
		this.empemail = empemail;
		this.empDesign = empDesign;
		this.doj = doj;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpsal() {
		return empsal;
	}

	public void setEmpsal(int empsal) {
		this.empsal = empsal;
	}

	public String getEmpemail() {
		return empemail;
	}

	public void setEmpemail(String empemail) {
		this.empemail = empemail;
	}

	public String getEmpDesign() {
		return empDesign;
	}

	public void setEmpDesign(String empDesign) {
		this.empDesign = empDesign;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", empName=" + empName + ", empsal=" + empsal + ", empemail=" + empemail
				+ ", empDesign=" + empDesign + ", doj=" + doj + "]";
	}
	
	
	
	
	

}
