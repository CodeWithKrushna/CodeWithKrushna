package com.anudip.exception;

public class EmployeeIdNotFoundExcepation extends RuntimeException
{
	public EmployeeIdNotFoundExcepation(String message) 
	{
		super(message);
	}

}
