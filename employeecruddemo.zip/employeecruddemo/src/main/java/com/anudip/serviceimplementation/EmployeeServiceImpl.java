package com.anudip.serviceimplementation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anudip.entity.Employee;
import com.anudip.exception.EmployeeIdNotFoundExcepation;
import com.anudip.repository.EmployeeRepository;
import com.anudip.service.EmpolyeeService;

@Service
public class EmployeeServiceImpl implements EmpolyeeService
{
	@Autowired
	EmployeeRepository empRepository;

	@Override
	public Employee addEmployee(Employee emp)
	{
		return empRepository.save(emp);
		 
	}

	@Override
	public Employee getEmployee(int id) 
	{
		
		return empRepository.findById(id).orElseThrow(()-> new EmployeeIdNotFoundExcepation("Student Id is not correct"));
	}

	@Override
	public String deleteEmployee() 
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee updateEmployee(int id)
	{
		// TODO Auto-generated method stub
		return null;
	}

}
