package com.anudip.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.anudip.entity.Employee;
import com.anudip.serviceimplementation.EmployeeServiceImpl;

//postman with send the request through http protocol
/*postMapping -- insert data
 * getMapping  - retrivr data
 * putMapping   -update data 
 * deleteMapping  - delete data
 * 
 *http:/localhost:8080/add
 * */
@RestController    // accept the request
public class EmployeeController 
{
	@Autowired
	EmployeeServiceImpl service;
	@PostMapping("/add")
	public Employee empAdd(@RequestBody Employee emp)
	{
		
		return service.addEmployee(emp);
		
	}
	
}
