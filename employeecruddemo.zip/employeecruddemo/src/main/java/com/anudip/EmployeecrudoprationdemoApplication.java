package com.anudip;

import org.springframework.boot.SpringApplication; 
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeecrudoprationdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeecrudoprationdemoApplication.class, args);
	}

}
