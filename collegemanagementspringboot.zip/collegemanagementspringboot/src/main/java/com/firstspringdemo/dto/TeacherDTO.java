package com.firstspringdemo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TeacherDTO 
{
	//@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private int tid;
	
	//@Column(length = 25, nullable = false)
	//@NotBlank(message = "Teacher name can not be Black")  // validation
	private String tName;
	
	//@Column(length = 25, nullable = false)
	//@NotBlank(message = "Teacher name can not be Black")  // validation
	private String tSurname;
	
	//@Column(length = 25, nullable = false,unique = true)
	//@NotBlank(message = "Teacher E-mail can not be Black")  // validation
	//@Email(message = "Email id is not proper") // email validation
	private String email;
	
	//@Column(length = 25, nullable = false,unique = true)
	//@NotNull(message = "Phone Number can not be Black")  // validation
	private String tphone;
	
	//@Column(length = 25, nullable = false)
	//@NotBlank(message = "Designation can not be Black")  // validation
	private String designation;

}
