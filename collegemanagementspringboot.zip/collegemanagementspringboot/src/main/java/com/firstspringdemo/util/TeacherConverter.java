package com.firstspringdemo.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import com.firstspringdemo.dto.TeacherDTO;
import com.firstspringdemo.entity.Teacher;

//this call will be responsibale to convert from DTO to entity and vice versa
//instead
@Component
public class TeacherConverter 
{
	public Teacher ConvertTeacherDTOToTeacher(TeacherDTO tdto) {
		
		Teacher tc=new Teacher();
		
		if(tdto!=null)
		{
			BeanUtils.copyProperties(tdto, tc);
		}
		return tc;
		
	}
	
	public TeacherDTO convertTeacherToTeacherDTO(Teacher teacher) 
	{
		TeacherDTO tdto=new TeacherDTO();
		
		if(teacher !=null)
		{
			BeanUtils.copyProperties(teacher, tdto);
			
		}
		return tdto;
		
	}
	

}
