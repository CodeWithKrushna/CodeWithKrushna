package com.firstspringdemo.services;

import com.firstspringdemo.entity.Deparment;

public interface DeparmentService 
{
	Deparment addDeparment(Deparment deparment);
	
	Deparment getDeparmentDetails(int did);
	
	Deparment updateDeparmentDetails(Deparment deparment,int did);
	
	void deleteDeparmentDetails(int did);
	

}


