package com.firstspringdemo.services;

import com.firstspringdemo.entity.Batches;


public interface BatcheseService 
{
	Batches addBatch(Batches batch);
	
	Batches getBatchDetails(int bid);
	
	Batches updateBatchDetails(Batches batches,int bid);
	
	void deleteBatchDetails(int bid);

	
}
 
 
