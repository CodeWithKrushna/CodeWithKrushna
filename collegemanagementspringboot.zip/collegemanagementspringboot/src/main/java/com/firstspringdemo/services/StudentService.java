package com.firstspringdemo.services;

import com.firstspringdemo.entity.Student;

public interface StudentService
{
	Student addStudent(Student student);
	Student getStudentDetails(int tid);
	
	Student updateStudentDetails(Student student,int tid);
	void deleteStudentDetalis(int tid);  

}   
