package com.firstspringdemo.services;

import com.firstspringdemo.entity.Courses;


public interface CourseService 
{
	Courses addCourses(Courses courses);
	
	Courses getCoursesDetails(int cid);
	
	Courses updateCoursesDetails(Courses courses,int cid);
	 
	void deleteCoursesDetails(int cid);
	

}

