package com.firstspringdemo.services;

import java.util.List;

import com.firstspringdemo.dto.TeacherDTO;
import com.firstspringdemo.entity.Teacher;

public interface TeacherServices
{
	TeacherDTO addTeacher(Teacher teacher);
	Teacher getTeacherDetails(int tid);
	
	Teacher updateTeacherDetails(Teacher teacher,int tid);
	void deleteTeacherDetalis(int tid); 
	
	//method to fetch teacher details based on phone number
	Teacher getTeacherByPhone(long tphone);
	// method to feach teacher details
	List<Teacher>getTeachersdesignation(String designation);
	
	List<Teacher>getTeacherName(String tName);
	
}
