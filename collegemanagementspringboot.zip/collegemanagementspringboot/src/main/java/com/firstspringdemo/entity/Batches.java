package com.firstspringdemo.entity;

import jakarta.persistence.Column; 
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

@Entity
public class Batches 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int bid;
	
	@Column(length=10, nullable = true)
	@NotNull(message = "Batch Name cannot be blank")
	private String bname;
	
	@Column(length=30, nullable = true)
	@NotNull(message = "Batch subject cannot be blank")
	private String subject;
	
	@Column(length=20, nullable = true)
	@NotNull(message = "Batch Starting Date cannot be blank")
	private String startdate;
	
	@Column(length=20, nullable = true)
	@NotNull(message = "Batch End Date cannot be blank")
	private String enddate;
	
	@Column(length=20, nullable = true)
	@NotNull(message = "Batch Duration cannot be blank")
	private int duration;

	

}


