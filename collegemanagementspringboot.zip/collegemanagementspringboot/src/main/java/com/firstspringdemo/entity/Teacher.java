package com.firstspringdemo.entity;

import java.util.List; 

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;   
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
public class Teacher 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int tid;
	
	@Column(length = 25, nullable = false)
	@NotBlank(message = "Teacher name can not be Black")  // validation
	private String tName;
	
	@Column(length = 25, nullable = false)
	@NotBlank(message = "Teacher name can not be Black")  // validation
	private String tSurname;
	
	@Column(length = 25, nullable = false,unique = true)
	@NotBlank(message = "Teacher E-mail can not be Black")  // validation
	@Email(message = "Email id is not proper") // email validation
	private String email;
	
	@Column(length = 25, nullable = false,unique = true)
	@NotNull(message = "Phone Number can not be Black")  // validation
	private String tphone;
	
	@Column(length = 25, nullable = false)
	@NotBlank(message = "Designation can not be Black")  // validation
	private String designation;


	@ManyToOne( fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name="deptID", referencedColumnName = "did")
	@JsonBackReference
	private Deparment department; 
	
	

}
