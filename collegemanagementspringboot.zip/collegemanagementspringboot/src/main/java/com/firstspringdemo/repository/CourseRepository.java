package com.firstspringdemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.firstspringdemo.entity.Courses;

public interface CourseRepository extends JpaRepository<Courses, Integer> 
{

}
