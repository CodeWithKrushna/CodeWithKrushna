package com.firstspringdemo.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.firstspringdemo.entity.Batches;

public interface BatchRepository extends JpaRepository<Batches, Integer>
{
 
}
