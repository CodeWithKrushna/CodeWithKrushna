package com.firstspringdemo.repository;

import org.springframework.data.jpa.repository.JpaRepository; 

import com.firstspringdemo.entity.Deparment;

public interface DeparmentRepository extends JpaRepository<Deparment, Integer>
{

}
