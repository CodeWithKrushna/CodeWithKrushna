package com.firstspringdemo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.firstspringdemo.entity.Teacher;

public interface TeacherRepository extends JpaRepository<Teacher, Integer> 
{
	@Query("select t from Teacher t where t.tphone=?1")
	Teacher findTeacherByPhone(long tphone);
	
	@Query("select t from Teacher t where t.tName=?1")
	List<Teacher> findTeacherTname(String tName);
	
	@Query("Select t from Teacher t where t.designation like ?1% order by tName")
	List<Teacher> findTeacherDesignation(String designation);

}
