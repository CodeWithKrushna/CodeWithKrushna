package com.firstspringdemo.exception;

public class TeacherIdNotFoundExcepation extends RuntimeException
{
	public TeacherIdNotFoundExcepation (String message) 
	{
		super(message);
	}

}
 