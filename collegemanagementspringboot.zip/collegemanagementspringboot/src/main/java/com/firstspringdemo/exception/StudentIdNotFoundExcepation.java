package com.firstspringdemo.exception;

public class StudentIdNotFoundExcepation extends RuntimeException
{
	public StudentIdNotFoundExcepation (String message)  
	{
		super(message);
	}

}
