package com.firstspringdemo.exception;

import org.springframework.http.HttpStatus;  
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@ResponseStatus
public class GlobalExcepationHandler extends ResponseEntityExceptionHandler 
{
	@ExceptionHandler(TeacherIdNotFoundExcepation.class)
	public  ResponseEntity<ErrorMassage> handleTeacherExcepation(TeacherIdNotFoundExcepation tx, WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND,tx.getMessage());
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er);
		
	}
	
	@ExceptionHandler(StudentIdNotFoundExcepation.class)
	public  ResponseEntity<ErrorMassage> handleStudentExcepation(StudentIdNotFoundExcepation tx, WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND,tx.getMessage());
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er);
		
	}
	
	@ExceptionHandler(BatchesIdNotFoundExcepation.class)
	public  ResponseEntity<ErrorMassage> handleBatchesExcepation(BatchesIdNotFoundExcepation tx, WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND,tx.getMessage());
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er);
		
	}
	
	@ExceptionHandler(DeparmentIdNotFoundExcepation.class)
	public  ResponseEntity<ErrorMassage> handleDeparmentExcepation(DeparmentIdNotFoundExcepation tx, WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND,tx.getMessage());
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er);
		
	}
	
	@ExceptionHandler(CoursesIdNotFoundExcepation.class)
	public  ResponseEntity<ErrorMassage> handleCoursesExcepation(CoursesIdNotFoundExcepation tx, WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND,tx.getMessage());
		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er);
		
	}
	

}
