package com.firstspringdemo.exception;

public class CoursesIdNotFoundExcepation extends RuntimeException
{
	public CoursesIdNotFoundExcepation(String message)
	{
		super(message);
	}

}
