package com.firstspringdemo.exception;

public class DeparmentIdNotFoundExcepation extends RuntimeException
{
	public DeparmentIdNotFoundExcepation(String message) 
	{
		super(message);
	}

}
