package com.firstspringdemo.exception;

public class BatchesIdNotFoundExcepation extends RuntimeException
{
	public BatchesIdNotFoundExcepation(String message) 
	{
	super(message); 
	}

}
