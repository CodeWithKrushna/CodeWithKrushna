package com.firstspringdemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.firstspringdemo.entity.Courses;
import com.firstspringdemo.services.CourseService;

import jakarta.validation.Valid;

@RestController 
public class CoursesController
{
	@Autowired
	CourseService courservi; 
	
	//http://locathost:8080/Courses/addCourses
	@PostMapping("/Courses/addCourses")
	public ResponseEntity<Courses>saveCourses(@Valid @RequestBody Courses courses)
	{
		return new ResponseEntity<Courses>(courservi.addCourses(courses),HttpStatus.CREATED) ;
		
	}
	
	//http://locathost:8080/Courses/getCourses/1
	@GetMapping("/Courses/getCourses/{cid}")
	public ResponseEntity<Courses>getCourses(@PathVariable("cid") int cid)
	{
		return new ResponseEntity<Courses>(courservi.getCoursesDetails(cid),HttpStatus.OK);
		
	}
	
	//http://locathost:8080/Courses/remove/1
	@DeleteMapping("/Courses/remove/{cid}")
	public ResponseEntity<String>deleteCourses(@PathVariable("cid") int cid)
	{
		courservi.deleteCoursesDetails(cid);
		return new ResponseEntity<String>("Delete Courses data Suceessfully......",HttpStatus.OK);
		
	}
	
	//http://locathost:8080/Courses/editCourses/1
	@PutMapping("/Courses/editCourses/{cid}")
	public ResponseEntity<Courses>editCourses(@Valid @PathVariable("cid")int cid,@RequestBody Courses courses)
	{
		return new ResponseEntity<Courses>(courservi.updateCoursesDetails(courses, cid),HttpStatus.OK) ;
		
	}

}
