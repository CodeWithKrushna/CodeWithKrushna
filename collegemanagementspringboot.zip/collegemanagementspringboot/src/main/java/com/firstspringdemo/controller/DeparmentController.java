package com.firstspringdemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.firstspringdemo.entity.Deparment;
import com.firstspringdemo.services.DeparmentService;

import jakarta.validation.Valid;

@RestController
public class DeparmentController
{
	@Autowired
	DeparmentService depServic;
	
	//http://localhost:8080/Deparment/addDeparment
	@PostMapping("/Deparment/addDeparment")
	public ResponseEntity<Deparment>saveDeparment(@Valid @RequestBody Deparment deparment )
	{
		return new ResponseEntity<Deparment>(depServic.addDeparment(deparment),HttpStatus.CREATED);
	}
	
	//http://locathost:8080/Deparment/getDeparment/1
	@GetMapping("/Deparment/getDeparment/{did}")
	public ResponseEntity<Deparment>getDeparment(@PathVariable("did") int did)
	{
		return new ResponseEntity<Deparment>(depServic.getDeparmentDetails(did),HttpStatus.OK);
		
	}
	
	//http://locathost:8080/Deparment/removeDeparment/1
	@DeleteMapping("/Deparment/removeDeparment/{did}")
	public ResponseEntity<String>deleteDeparment(@PathVariable("did")int did)
	{
		depServic.deleteDeparmentDetails(did);
		return new ResponseEntity<String>("Delete Deparment data Suceessfully........ ",HttpStatus.OK);
		
	}
	
	//http://locathost:8080/Deparment/editDeparment/1
	@PutMapping("/Deparment/editDeparment/{did}")
	public ResponseEntity<Deparment>editDeparment(@Valid@PathVariable("did") int did,@RequestBody Deparment deparment)
	{
		return new ResponseEntity<Deparment>(depServic.updateDeparmentDetails(deparment, did),HttpStatus.OK);
		
	}
	

}
