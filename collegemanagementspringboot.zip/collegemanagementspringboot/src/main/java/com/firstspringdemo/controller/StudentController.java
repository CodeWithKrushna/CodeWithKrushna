package com.firstspringdemo.controller;

import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.firstspringdemo.entity.Student;
import com.firstspringdemo.services.StudentService;

import jakarta.validation.Valid;

@RestController
public class StudentController 
{
	@Autowired
	StudentService stuService;
	
	//http://localhost:8080/Student/addStudent
	@PostMapping("/Student/addStudent")
	public ResponseEntity<Student>saveStudent(@Valid @RequestBody Student student)
	{ 
		return new ResponseEntity<Student>(stuService.addStudent(student),HttpStatus.CREATED);
		
	}
	
	//http://locathost:8080/Student/get/(1)
	@GetMapping("Student/get/{tid}")
	public ResponseEntity<Student>getStudent(@PathVariable("tid")int tid)
	{
		return new ResponseEntity<Student>(stuService.getStudentDetails(tid),HttpStatus.OK);
	 	
	}
	//http://locathost:8080/Student/remove/(1)
	@DeleteMapping("/Student/remove/{tid}")
	public ResponseEntity<String>deleteStudent(@PathVariable("tid")int tid)
	{
		stuService.deleteStudentDetalis(tid);
		return new ResponseEntity<String>("Delete Student Data Suceessfully.......",HttpStatus.OK);
		
	}
	
	//use PutMapping to edit existing data
	@PutMapping("/Student/editstudent/{tid}")
	public ResponseEntity<Student>editStudent(@Valid@PathVariable("tid")int tid,@RequestBody Student student)
	{
		return new ResponseEntity<Student>(stuService.updateStudentDetails(student, tid),HttpStatus.OK); 
		
	}	
	
	
	

}
