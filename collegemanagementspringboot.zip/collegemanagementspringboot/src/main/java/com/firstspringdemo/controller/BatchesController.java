package com.firstspringdemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus; 
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.firstspringdemo.entity.Batches;
import com.firstspringdemo.services.BatcheseService;

import jakarta.validation.Valid;

@RestController
public class BatchesController 
{
	@Autowired
	BatcheseService batservic;
	
	//http://localhost:8080/Batches/addbatches
	@PostMapping("Batches/addbatches")
	public ResponseEntity<Batches>saveBatches(@Valid@RequestBody Batches batches)
	{
		return new ResponseEntity<Batches>(batservic.addBatch(batches),HttpStatus.CREATED);
		
	}
	
	//http://localhost:8080/Batches/getBatches/1
	@GetMapping("Batches/getBatches/{bid}")
	public ResponseEntity<Batches>getBatches(@PathVariable("bid")int bid)
	{
		
		return new ResponseEntity<Batches>(batservic.getBatchDetails(bid),HttpStatus.OK);
		
	}
	
	//http://locathost:8080/Batches/remove/1
	@DeleteMapping("Batches/remove/{bid}")
	public ResponseEntity<String>deleteBatches(@PathVariable("bid") int bid)
	{
		batservic.deleteBatchDetails(bid);
	
		return new ResponseEntity<String>("Delete Batch data Suceessfully.......",HttpStatus.OK);
		
	}
	
	//http://locathost:8080/Batches/editBatches/1
	@PutMapping("Batches/editBatches/{bid}")
	public ResponseEntity<Batches>editBatches(@Valid @PathVariable("bid") int bid,@RequestBody Batches batches)
	{
		return new ResponseEntity<Batches>(batservic.updateBatchDetails(batches, bid),HttpStatus.OK);
		
	}	

}
