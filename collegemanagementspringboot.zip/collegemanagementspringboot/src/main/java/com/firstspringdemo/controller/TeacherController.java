package com.firstspringdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.firstspringdemo.dto.TeacherDTO;
import com.firstspringdemo.entity.Teacher;
import com.firstspringdemo.services.TeacherServices;
import com.firstspringdemo.util.TeacherConverter;

import jakarta.validation.Valid;

@RestController  
public class TeacherController 
{
	@Autowired
	TeacherServices tservice;
	
	@Autowired
	TeacherConverter tconveter;
	//postman 
	//http://locathost:8080/Teacher/getTeacher(1)
	
	/*
	@PostMapping("/Teacher/addTeacher")
	public ResponseEntity<Teacher> saveTeacher(@Valid@RequestBody Teacher teacher)
	{
		return new ResponseEntity<Teacher>(tservice.addTeacher(teacher), HttpStatus.CREATED);
		
		
	}*/
	
	
	@PostMapping("/Teacher/addTeacher")
	public ResponseEntity<TeacherDTO> saveTeacher(@Valid@RequestBody TeacherDTO tdo)
	{
		Teacher teacher=tconveter.ConvertTeacherDTOToTeacher(tdo);
		return new ResponseEntity<TeacherDTO>(tservice.addTeacher(teacher), HttpStatus.CREATED);
		
		
	}
	
	//http://localhost:8080/Teacher/getTeacher(1)
	@GetMapping("/Teacher/get/{tid}")
	public ResponseEntity<Teacher>getTeacher(@PathVariable("tid")int tid)
	{
		return new ResponseEntity<Teacher>(tservice.getTeacherDetails(tid),HttpStatus.OK);
		
	}
	@DeleteMapping("/Teacher/remove/{tid}")
	public ResponseEntity<String>deleteTeacher(@PathVariable("tid")int tid)
	{
		tservice.deleteTeacherDetalis(tid);
		return new ResponseEntity<String>("Delete Suceessfully.....",HttpStatus.OK);
		
	}
	
	@PutMapping("/Teacher/editTeacher/{tid}")
	public ResponseEntity<Teacher>editTeacher(@Valid@PathVariable("tid")int tid,@RequestBody Teacher teacher)
	{
		return new ResponseEntity<Teacher>(tservice.updateTeacherDetails(teacher, tid),HttpStatus.OK);
		
		
	}
	
	@GetMapping("Teacher/getphone/{tphone}")
	public ResponseEntity<Teacher>getTeacherPhone(@PathVariable("tphone")long tphone)
	{
		return new ResponseEntity<Teacher>(tservice.getTeacherByPhone(tphone),HttpStatus.OK);
		
		
	}
	
	@GetMapping("Teacher/getTeacherdesignation/{designation}")
	public List<Teacher>getTeacherdesignation(@PathVariable("designation")String designation)
	{
		return tservice.getTeachersdesignation(designation);
		
	}
	
	
	

}
