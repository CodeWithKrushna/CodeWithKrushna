package com.firstspringdemo.serviceimp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.firstspringdemo.entity.Courses;
import com.firstspringdemo.exception.CoursesIdNotFoundExcepation;
import com.firstspringdemo.repository.CourseRepository;
import com.firstspringdemo.services.CourseService;
@Service
public class CoursesRepositoryImpl implements CourseService
{
	@Autowired
	CourseRepository coureposi;

	@Override
	public Courses addCourses(Courses courses)
	{
		
		
		return coureposi.save(courses);
	}

	@Override
	public Courses getCoursesDetails(int cid) 
	{
		
		return coureposi.findById(cid).orElseThrow(()->new CoursesIdNotFoundExcepation("Courese Id is not correct") );
	}
 
	@Override   // get data
	public Courses updateCoursesDetails(Courses courses, int cid) 
	{
		Courses updateCourses=coureposi.findById(cid).orElseThrow(()->new CoursesIdNotFoundExcepation("Courese Id is not correct"));
		
		//set value
		updateCourses.setCourseName(courses.getCourseName());
		updateCourses.setCourseFees(courses.getCourseFees());
		updateCourses.setDuration(courses.getDuration());
		
		//save data
		coureposi.save(updateCourses);
		
		return updateCourses;
	}

	@Override
	public void deleteCoursesDetails(int cid) 
	{
		Courses deleteCourses=coureposi.findById(cid).orElseThrow(()->new CoursesIdNotFoundExcepation("Courese Id is not correct")); 
				coureposi.delete(deleteCourses);
		
	}

}
