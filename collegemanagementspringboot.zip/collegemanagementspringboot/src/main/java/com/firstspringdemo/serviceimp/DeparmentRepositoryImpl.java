package com.firstspringdemo.serviceimp;

import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Service;

import com.firstspringdemo.entity.Deparment;
import com.firstspringdemo.exception.DeparmentIdNotFoundExcepation;
import com.firstspringdemo.repository.DeparmentRepository;
import com.firstspringdemo.services.DeparmentService;

@Service
public class DeparmentRepositoryImpl implements DeparmentService
{
	@Autowired
	DeparmentRepository deprepos;

	@Override
	public Deparment addDeparment(Deparment deparment) 
	{
		
		return deprepos.save(deparment);
	}

	@Override
	public Deparment getDeparmentDetails(int did)
	{
		
		return deprepos.findById(did).orElseThrow(()->new DeparmentIdNotFoundExcepation("Student Id is not correct"));
	}

	@Override   // get data
	public Deparment updateDeparmentDetails(Deparment deparment, int did) 
	{
		Deparment updateDeparment=deprepos.findById(did).orElseThrow(()->new DeparmentIdNotFoundExcepation("Student Id is not correct"));
		
		//set data
		updateDeparment.setDeptName(deparment.getDeptName());
		updateDeparment.setDeptHOD(deparment.getDeptHOD());
		
		//save data
		deprepos.save(updateDeparment);
		return updateDeparment;
	}

	@Override
	public void deleteDeparmentDetails(int did) 
	{
		Deparment deleteDeparment=deprepos.findById(did).orElseThrow(()->new DeparmentIdNotFoundExcepation("Student Id is not correct"));
		deprepos.delete(deleteDeparment);
		
	}

}
