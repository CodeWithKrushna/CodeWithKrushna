package com.firstspringdemo.serviceimp;

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service;

import com.firstspringdemo.dto.TeacherDTO;
import com.firstspringdemo.entity.Teacher;
import com.firstspringdemo.exception.TeacherIdNotFoundExcepation;
import com.firstspringdemo.repository.TeacherRepository;
import com.firstspringdemo.services.TeacherServices;
import com.firstspringdemo.util.TeacherConverter;

@Service
public class TeacherServicelmple implements TeacherServices 
{
	@Autowired
	TeacherRepository teacherRepo;


	@Autowired
	TeacherConverter tcover;
	@Override
	public TeacherDTO addTeacher(Teacher teacher) 
	{	
		return tcover.convertTeacherToTeacherDTO (teacherRepo.save(teacher));
	}
 
	@Override
	public Teacher getTeacherDetails(int tid) {
		
		return teacherRepo.findById(tid).orElseThrow(()-> new TeacherIdNotFoundExcepation("Teacher Id is not correct"));//(()->)lambda
		
 
	}

	@Override // get 
	public Teacher updateTeacherDetails(Teacher teacher, int tid) {
		Teacher updateTeacher= teacherRepo.findById(tid).orElseThrow(()->new TeacherIdNotFoundExcepation("Teacher Id is not correct"));
		//set new value
		updateTeacher.setTphone(teacher.getTphone());
		updateTeacher.setDesignation(teacher.getDesignation());
		//save
		teacherRepo.save(updateTeacher);
		
		return updateTeacher; 
	}
 
	@Override
	public void deleteTeacherDetalis(int tid) 
	{
		Teacher delTeacher=teacherRepo.findById(tid).orElseThrow(()->new TeacherIdNotFoundExcepation("Teacher Id is not correct"));
		teacherRepo.delete(delTeacher);
		
	}

	@Override
	public Teacher getTeacherByPhone(long tphone) {
		// TODO Auto-generated method stub
		return teacherRepo.findTeacherByPhone(tphone);
	}

	public List<Teacher> getTeachersdesignation(String designation) {
		// TODO Auto-generated method stub
		return teacherRepo.findTeacherDesignation(designation);
	}

	@Override
	public List<Teacher> getTeacherName(String tName) {
		// TODO Auto-generated method stub
		return teacherRepo.findTeacherTname(tName);
	}

}
