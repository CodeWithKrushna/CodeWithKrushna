package com.firstspringdemo.serviceimp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.firstspringdemo.entity.Batches;
import com.firstspringdemo.exception.BatchesIdNotFoundExcepation;
import com.firstspringdemo.repository.BatchRepository;
import com.firstspringdemo.services.BatcheseService;
@Service
public class BatchesRepositoryImpl implements BatcheseService
{
	@Autowired
	BatchRepository batchreposi;

	@Override
	public Batches addBatch(Batches batches) // change batch to batches
	{
		
		return batchreposi.save(batches);
	}

	@Override
	public Batches getBatchDetails(int bid)
	{
		return batchreposi.findById(bid).orElseThrow(()->new BatchesIdNotFoundExcepation("Student Id is not correct"));
	}
  
	@Override  // get data
	public Batches updateBatchDetails(Batches batches, int bid) 
	{
		Batches updateBatches=batchreposi.findById(bid).orElseThrow(()->new BatchesIdNotFoundExcepation("Student Id is not correct"));
		
		// set data
		updateBatches.setBname(batches.getBname());
		updateBatches.setSubject(batches.getSubject());
		updateBatches.setStartdate(batches.getStartdate());
		updateBatches.setEnddate(batches.getEnddate());
		updateBatches.setDuration(batches.getDuration());
		
		//save data
		batchreposi.save(updateBatches);
		return updateBatches;
	}

	@Override
	public void deleteBatchDetails(int bid) 
	{
		Batches deleteBatches=batchreposi.findById(bid).orElseThrow(()->new BatchesIdNotFoundExcepation("Student Id is not correct"));
		batchreposi.delete(deleteBatches);
		
	}
	

}
