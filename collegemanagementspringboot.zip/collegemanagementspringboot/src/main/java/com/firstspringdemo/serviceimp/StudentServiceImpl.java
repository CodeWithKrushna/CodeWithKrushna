package com.firstspringdemo.serviceimp;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service;
import com.firstspringdemo.entity.Student;
import com.firstspringdemo.exception.StudentIdNotFoundExcepation;
import com.firstspringdemo.repository.StudentRepository;
import com.firstspringdemo.services.StudentService;
@Service
public class StudentServiceImpl implements StudentService 
{
	@Autowired
	StudentRepository sturepo; 
	
	@Override
	public Student addStudent(Student student) 
	{
		
		return sturepo.save(student);
	}

	@Override
	public Student getStudentDetails(int tid) 
	{
		 return sturepo.findById(tid).orElseThrow(()-> new StudentIdNotFoundExcepation("Student Id is not correct"));//(()->)lambda
	}

	@Override   //get data
	public Student updateStudentDetails(Student student, int tid)
	{
		Student updaStudent=sturepo.findById(tid).orElseThrow(()->new StudentIdNotFoundExcepation("Student Id is not correct"));
		
		//set value
		updaStudent.setSphone(student.getSphone());
		updaStudent.setSeduc(student.getSeduc());
		
		//save data and return
		sturepo.save(updaStudent);
		return updaStudent;
	}

	@Override
	public void deleteStudentDetalis(int tid) 
	{
		Student delStudent=sturepo.findById(tid).orElseThrow(()->new StudentIdNotFoundExcepation("Student Id is not correct"));
		sturepo.delete(delStudent);
	}
	

}
