package com.firstspringdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyfirstspringbootdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
