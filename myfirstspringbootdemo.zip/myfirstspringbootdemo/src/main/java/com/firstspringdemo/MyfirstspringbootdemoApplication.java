package com.firstspringdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyfirstspringbootdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyfirstspringbootdemoApplication.class, args);
	}

}
