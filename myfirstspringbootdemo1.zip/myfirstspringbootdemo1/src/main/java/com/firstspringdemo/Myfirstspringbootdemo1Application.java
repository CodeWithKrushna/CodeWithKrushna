package com.firstspringdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Myfirstspringbootdemo1Application
{

	public static void main(String[] args)
	{
		
		SpringApplication.run(Myfirstspringbootdemo1Application.class, args);
	}

}
