package com.employee.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employee.entity.Employeee;

public interface EmployeeeRespository extends JpaRepository<Employeee, Integer>
{

}
