package com.employee.servicesimplementation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.entity.Employeee;
import com.employee.excepation.EmployeeeIdNotFoundExcepation;
import com.employee.respository.EmployeeeRespository;
import com.employee.services.EmployeeeServices;

@Service
public class EmployeeeServicesImpl implements EmployeeeServices
{
	@Autowired
	EmployeeeRespository EmpRespo;

	@Override
	public Employeee addEmployeeeDetails(Employeee emp)
	{
		return EmpRespo.save(emp);
	}

	@Override  
	public Employeee getEmployeeeDetails(int id) 
	{
		return EmpRespo.findById(id).orElseThrow(()-> new EmployeeeIdNotFoundExcepation("Employee Id is not correct"));
	}

	

	@Override
	public Employeee updateEmployeeeDetails(Employeee emp, int id) 
	{
		Employeee updateEmployee=EmpRespo.findById(id).orElseThrow(()-> new EmployeeeIdNotFoundExcepation("Employee Id is not correct"));
		//set data
		updateEmployee.setFirstName(emp.getFirstName());
		updateEmployee.setLastName(emp.getLastName());
		updateEmployee.setEmailId(emp.getEmailId());
		
		//save
		EmpRespo.save(updateEmployee);
		return updateEmployee;
	}

	@Override
	public void deleteEmployeeeDetails(int id) 
	{
		Employeee deleteEmployee=EmpRespo.findById(id).orElseThrow(()-> new EmployeeeIdNotFoundExcepation("Employee Id is not correct"));
		EmpRespo.delete(deleteEmployee);
		
	}

	@Override
	public List<Employeee> getAllDetails(Employeee employeee) {
		
		return EmpRespo.findAll();
	}

	

}
