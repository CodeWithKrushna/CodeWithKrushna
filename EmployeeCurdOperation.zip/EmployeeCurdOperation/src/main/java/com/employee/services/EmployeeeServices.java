package com.employee.services;

import java.util.List;

import com.employee.entity.Employeee;

public interface EmployeeeServices 
{
	public Employeee addEmployeeeDetails(Employeee emp);
	public Employeee getEmployeeeDetails(int id);
	void deleteEmployeeeDetails(int id);
	public Employeee updateEmployeeeDetails(Employeee emp ,int id);
	public List<Employeee> getAllDetails(Employeee employeee);
 
}
