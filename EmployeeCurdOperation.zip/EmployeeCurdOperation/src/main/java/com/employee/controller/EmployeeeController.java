package com.employee.controller;

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee.entity.Employeee;
import com.employee.respository.EmployeeeRespository;
import com.employee.services.EmployeeeServices;

import jakarta.validation.Valid;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class EmployeeeController 
{
	@Autowired
	EmployeeeServices EmpServices;
	
	//http://localhost:8080/Employeee/addEmp
	@PostMapping("/Employeee")
	public ResponseEntity<Employeee>saveEmp(@Valid @RequestBody Employeee emp)
	{
		return new ResponseEntity<Employeee>(EmpServices.addEmployeeeDetails(emp),HttpStatus.CREATED);
		
	}
	
	//http://localhost:8080/Employeee/getEmp/1
	@GetMapping("/Employeee/{id}")
	public ResponseEntity<Employeee>getEmp(@PathVariable("id")int id)
	{
		return new ResponseEntity<Employeee>(EmpServices.getEmployeeeDetails(id),HttpStatus.OK);
		
	}
	
	//http://localhost:8080/Employeee/editEmp/1
	@PutMapping("/Employeee/{id}")
	public ResponseEntity<Employeee>editEmp(@Valid@PathVariable("id")int id,@RequestBody Employeee employeee)
	{
		return new ResponseEntity<Employeee>(EmpServices.updateEmployeeeDetails(employeee, id),HttpStatus.OK);
		
	}
	
	//http://localhost:8080/Employeee/deleteEmp/1
	@DeleteMapping("/Employeee/{id}")
	public ResponseEntity<String>deleteEmp(@PathVariable("id")int id)
	{
		EmpServices.deleteEmployeeeDetails(id);
		return new ResponseEntity<String>("Delete Employee Data Suceessfully............",HttpStatus.OK);
		
	}
	
	//http://localhost:8080/Employeee/All
	@GetMapping("/Employeee/All") 
	public ResponseEntity<List> getAllEmployees(Employeee employeee) 
	{ 
		return new ResponseEntity<List>(EmpServices.getAllDetails(employeee),HttpStatus.OK);
		
	}
	
	

	

}
