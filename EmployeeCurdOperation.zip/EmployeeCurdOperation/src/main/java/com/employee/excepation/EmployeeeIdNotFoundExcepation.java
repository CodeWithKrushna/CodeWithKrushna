package com.employee.excepation;

public class EmployeeeIdNotFoundExcepation extends RuntimeException
{
	public EmployeeeIdNotFoundExcepation(String message) 
	{
		super(message);
	}

}
